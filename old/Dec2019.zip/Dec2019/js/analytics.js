//Remplazar 'UA-XXXXX-Y'
window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
ga('create', 'UA-140918597-1', 'auto');
ga('send', 'pageview');
