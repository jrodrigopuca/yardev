

$( document ).ready(function() {
    Waves.attach('.btn', ['waves-button', 'waves-float']);
    Waves.init();
})